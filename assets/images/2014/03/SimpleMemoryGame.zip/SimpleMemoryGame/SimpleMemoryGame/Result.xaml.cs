﻿using Microsoft.Phone.Controls;

namespace SimpleMemoryGame
{
    public partial class Result : PhoneApplicationPage
    {
        public Result()
        {
            InitializeComponent();
        }
    }
}