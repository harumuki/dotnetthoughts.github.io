﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;

namespace SimpleMemoryGame
{
    public partial class About : PhoneApplicationPage
    {
        public About()
        {
            InitializeComponent();
        }

        private void SendFeedback_Click(object sender, RoutedEventArgs e)
        {
            var mailTask = new EmailComposeTask();
            mailTask.To = "wp7support@dotnetthoughts.net";
            mailTask.Subject = "Feedback about Memory Game";
            mailTask.Show();
        }

        private void ReviewTheApp_Click(object sender, RoutedEventArgs e)
        {
            var reviewTask = new MarketplaceReviewTask();
            reviewTask.Show();
        }

        private void AppUrl_Click(object sender, RoutedEventArgs e)
        {
            var browserTask = new WebBrowserTask();
            browserTask.Uri = new Uri("http://www.dotnetthoughts.net", UriKind.Absolute);
            browserTask.Show();
        }
    }
}