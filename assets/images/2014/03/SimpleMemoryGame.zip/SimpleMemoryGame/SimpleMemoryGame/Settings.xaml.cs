﻿using System;
using System.IO.IsolatedStorage;
using System.Linq;
using Microsoft.Phone.Controls;
using System.Windows;

namespace SimpleMemoryGame
{
    public partial class Settings : PhoneApplicationPage
    {
        public Settings()
        {
            InitializeComponent();
            var level = IsolatedStorageSettings.ApplicationSettings["Level"].ToString();
            var type = IsolatedStorageSettings.ApplicationSettings["Type"].ToString();
            PopulatedSelectedItem(level, LevelSelection);
            PopulatedSelectedItem(type, TypeSelection);
            EnableTimer.IsChecked = Convert.ToBoolean(IsolatedStorageSettings.ApplicationSettings["EnableTimer"]);
        }

        private void PopulatedSelectedItem(string level, ListPicker listpicker)
        {
            foreach (var listPickerItem in listpicker.Items.Cast<ListPickerItem>().Where(listPickerItem => listPickerItem.Tag.ToString().Equals(level)))
            {
                listpicker.SelectedItem = listPickerItem;
                break;
            }
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            IsolatedStorageSettings.ApplicationSettings["Level"] = (LevelSelection.SelectedItem as ListPickerItem).Tag.ToString();
            IsolatedStorageSettings.ApplicationSettings["Type"] = (TypeSelection.SelectedItem as ListPickerItem).Tag.ToString();
            IsolatedStorageSettings.ApplicationSettings["EnableTimer"] = EnableTimer.IsChecked.Value;
            IsolatedStorageSettings.ApplicationSettings.Save();

            base.OnBackKeyPress(e);
        }

        private void ResetScore_Checked(object sender, System.Windows.RoutedEventArgs e)
        {
            if (ResetScore.IsChecked.Value && MessageBox.Show("Reset all the scores?", "Confirm", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                ResetScore.IsChecked = false;
            }
        }
    }
}