﻿using System;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Phone.Controls;

namespace SimpleMemoryGame
{
    public partial class MainPage : PhoneApplicationPage
    {
        private DispatcherTimer _timer;
        private DispatcherTimer _displayTimer;
        private bool _firstButtonOpened;
        private bool _secondButtonOpened;
        private string _firstButtonText;
        private string _secondButtonText;
        private Button _firstButton;
        private Button _secondButton;
        private int _moves;
        private int _cleared;
        private int _level = 1;
        private int _type = 1;
        private bool _enableTimer = true;
        private bool _isGameInProgress = false;
        private int _timeInSeconds = 1;
        private readonly Dictionary<int, ImageBrush> _imageDict;
        private readonly Dictionary<int, SolidColorBrush> _brushDict;
        private readonly Dictionary<int, string> _alphabetDict;

        public MainPage()
        {
            InitializeComponent();

            _imageDict = new Dictionary<int, ImageBrush>
            {
                {
                    1,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.acorn.png", UriKind.Relative))
                    }
                },
                {
                    2,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.adobe.acrobat.png", UriKind.Relative))
                    }
                },
                {
                    3,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.cards.club.png", UriKind.Relative))
                    }
                },
                {
                    4,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.chat.png", UriKind.Relative))
                    }
                },
                {
                    5,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.chess.horse.png", UriKind.Relative))
                    }
                },
                {
                    6,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.controller.xbox.png", UriKind.Relative))
                    }
                },
                {
                    7,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.dropbox.solid.png", UriKind.Relative))
                    }
                },
                {
                    8,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.github.png", UriKind.Relative))
                    }
                },
                {
                    9,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.globe.png", UriKind.Relative))
                    }
                },
                {
                    10,
                    new ImageBrush()
                    {
                        ImageSource =
                            new BitmapImage(new Uri("/Images/appbar.hardware.headphones.png", UriKind.Relative))
                    }
                },
                {
                    11,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.language.java.png", UriKind.Relative))
                    }
                },
                {
                    12,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.marketplace.png", UriKind.Relative))
                    }
                },
                {
                    13,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.os.android.png", UriKind.Relative))
                    }
                },
                {
                    14,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.os.windowsphone.png", UriKind.Relative))
                    }
                },
                {
                    15,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.potion.png", UriKind.Relative))
                    }
                },
                {
                    16,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.settings.png", UriKind.Relative))
                    }
                },
                {
                    0,
                    new ImageBrush()
                    {
                        ImageSource = new BitmapImage(new Uri("/Images/appbar.sport.football.png", UriKind.Relative))
                    }
                }
            };

            _brushDict = new Dictionary<int, SolidColorBrush>
            {
                {0, new SolidColorBrush(Color.FromArgb(255, 164, 196, 0))},
                {1, new SolidColorBrush(Color.FromArgb(255, 96, 169, 23))},
                {2, new SolidColorBrush(Color.FromArgb(255, 0, 138, 0))},
                {3, new SolidColorBrush(Color.FromArgb(255, 0, 171, 169))},
                {4, new SolidColorBrush(Color.FromArgb(255, 27, 161, 226))},
                {5, new SolidColorBrush(Color.FromArgb(255, 0, 80, 239))},
                {6, new SolidColorBrush(Color.FromArgb(255, 106, 0, 255))},
                {7, new SolidColorBrush(Color.FromArgb(255, 170, 0, 255))},
                {8, new SolidColorBrush(Color.FromArgb(255, 244, 114, 208))},
                {9, new SolidColorBrush(Color.FromArgb(255, 216, 0, 115))},
                {10, new SolidColorBrush(Color.FromArgb(255, 162, 0, 37))},
                {11, new SolidColorBrush(Color.FromArgb(255, 229, 20, 0))},
                {12, new SolidColorBrush(Color.FromArgb(255, 250, 104, 0))},
                {13, new SolidColorBrush(Color.FromArgb(255, 240, 163, 10))},
                {14, new SolidColorBrush(Color.FromArgb(255, 227, 200, 0))},
                {15, new SolidColorBrush(Color.FromArgb(255, 130, 90, 44))},
                {16, new SolidColorBrush(Color.FromArgb(255, 109, 135, 100))},
                {17, new SolidColorBrush(Color.FromArgb(255, 100, 118, 135))},
                {18, new SolidColorBrush(Color.FromArgb(255, 118, 96, 138))},
                {19, new SolidColorBrush(Color.FromArgb(255, 135, 121, 78))}
            };

            _alphabetDict = new Dictionary<int, string>
            {
                {0, "A"},
                {1, "B"},
                {2, "C"},
                {3, "D"},
                {4, "E"},
                {5, "F"},
                {6, "G"},
                {7, "H"},
                {8, "I"},
                {9, "K"},
                {10, "L"},
                {11, "M"},
                {12, "N"},
                {13, "O"},
                {14, "P"},
                {15, "Q"},
                {16, "R"},
                {17, "S"},
                {18, "T"},
                {19, "U"}
            };
        }

        private DispatcherTimer TimeDisplayTimer
        {
            get
            {
                if (_displayTimer != null) return _displayTimer;
                _displayTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
                _displayTimer.Tick += (o, e) =>
                {
                    DisplayTimer.Text = string.Format("{0} SECONDS", _timeInSeconds++);
                };

                return _displayTimer;
            }
        }

        private void InitializeData()
        {
            _firstButton = null;
            _firstButtonOpened = false;
            _firstButtonText = null;
            _secondButton = null;
            _secondButtonOpened = false;
            _secondButtonText = null;

            var rows = ContentPanel.RowDefinitions.Count;
            var cols = ContentPanel.ColumnDefinitions.Count;
            var total = rows * cols;
            var valuesReqd = total / 2;
            var list = new List<int>(valuesReqd);
            var random = new Random();
            var loopCounter = 0;
            for (; ; )
            {
                var rowPos = random.Next(0, rows);
                var colPos = random.Next(0, cols);
                var button = ContentPanel.GetControl<Button>(rowPos, colPos);
                var buttonValue = random.Next(0, valuesReqd);
                var countOfItemInList = list.Count(x => x == buttonValue);
                if (button.Tag == null && countOfItemInList <= 1)
                {
                    button.Tag = buttonValue;
                    list.Add(buttonValue);
                    loopCounter++;
                    if (loopCounter == total)
                    {
                        break;
                    }
                }
            }
        }

        private void StartTimer()
        {
            if (!TimeDisplayTimer.IsEnabled)
            {
                TimeDisplayTimer.Start();
            }
        }

        private void StopTimer()
        {
            if (TimeDisplayTimer.IsEnabled)
            {
                TimeDisplayTimer.Stop();
                DisplayTimer.Text = "0 SECONDS";
                _timeInSeconds = 1;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            StartTimer();
            _isGameInProgress = true;
            var button = sender as Button;
            if (!_firstButtonOpened)
            {
                _firstButtonOpened = true;
                _firstButton = button;
                _firstButtonText = button.Tag.ToString();
                ShowCurrentType(button);
            }
            else if (_firstButtonOpened && !_secondButtonOpened)
            {
                if (_firstButton.GetHashCode() == button.GetHashCode())
                {
                    return;
                }

                _secondButtonOpened = true;
                _secondButton = button;
                _secondButtonText = button.Tag.ToString();
                ShowCurrentType(button);
            }

            if (_firstButtonOpened && _secondButtonOpened)
            {
                if (_timer.IsEnabled)
                {
                    _timer.Stop();
                }
                else
                {
                    _timer.Start();
                }
            }
        }

        private void ShowCurrentType(Button button)
        {
            if (_type == 1)
            {
                button.Content = button.Tag.ToString();
            }

            if (_type == 2)
            {
                button.Background = _brushDict[int.Parse(button.Tag.ToString())];
            }

            if (_type == 3)
            {
                button.Background = _imageDict[int.Parse(button.Tag.ToString())];
            }

            if (_type == 4)
            {
                button.Content = _alphabetDict[int.Parse(button.Tag.ToString())];
            }
        }

        private void Process()
        {
            if (_timer.IsEnabled)
            {
                _timer.Stop();
            }
            else
            {
                _timer.Start();
            }

            if (_firstButtonText == _secondButtonText)
            {
                _firstButton.Visibility = Visibility.Collapsed;
                _secondButton.Visibility = Visibility.Collapsed;
                _cleared++;
            }

            _moves++;
            Moves.Text = string.Format("MOVES {0}", _moves);

            _firstButton.IsEnabled = _secondButton.IsEnabled = true;
            _firstButton.Background = _secondButton.Background = new SolidColorBrush(Colors.Transparent);
            _firstButtonText = string.Empty;
            _firstButton.Content = string.Empty;
            _secondButtonText = string.Empty;
            _secondButton.Content = string.Empty;
            _firstButtonOpened = false;
            _secondButtonOpened = false;

            var rows = ContentPanel.RowDefinitions.Count;
            var cols = ContentPanel.ColumnDefinitions.Count;
            if (_cleared == (rows * cols) / 2)
            {
                _isGameInProgress = false;
                Dispatcher.BeginInvoke(() => NavigationService.Navigate(new Uri("/Result.xaml", UriKind.Relative)));
            }
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            if (_isGameInProgress)
            {
                if (MessageBox.Show("Are you sure want to close?", "Confirm", MessageBoxButton.OKCancel) == MessageBoxResult.Cancel)
                {
                    e.Cancel = true;
                }
            }
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            _timer = new DispatcherTimer();
            _timer.Tick += (o, v) => Process();
            _timer.Interval = new TimeSpan(0, 0, 0, 0, 300);
            if (!IsolatedStorageSettings.ApplicationSettings.Contains("Level") ||
                !IsolatedStorageSettings.ApplicationSettings.Contains("Type") ||
                !IsolatedStorageSettings.ApplicationSettings.Contains("EnableTimer"))
            {
                IsolatedStorageSettings.ApplicationSettings["Level"] = 1;
                IsolatedStorageSettings.ApplicationSettings["Type"] = 1;
                IsolatedStorageSettings.ApplicationSettings["EnableTimer"] = true;
                IsolatedStorageSettings.ApplicationSettings.Save();
            }

            _level = int.Parse(IsolatedStorageSettings.ApplicationSettings["Level"].ToString());
            _type = int.Parse(IsolatedStorageSettings.ApplicationSettings["Type"].ToString());
            _enableTimer = bool.Parse(IsolatedStorageSettings.ApplicationSettings["EnableTimer"].ToString());
            DisplayTimer.Visibility = _enableTimer ? Visibility.Visible : Visibility.Collapsed;
            StopTimer();
            CreateNewGame();
            base.OnNavigatedTo(e);
        }

        private void CreateNewGame()
        {
            switch (_level)
            {
                case 1:
                    CreateDynamicGrid(4, 3);
                    break;
                case 2:
                    CreateDynamicGrid(5, 4);
                    break;
                case 3:
                    CreateDynamicGrid(6, 5);
                    break;
            }

            if (_level > 0)
            {
                InitializeData();
            }
        }

        private void CreateDynamicGrid(int rows, int cols)
        {
            ContentPanel.Children.Clear();
            ContentPanel.RowDefinitions.Clear();
            ContentPanel.ColumnDefinitions.Clear();
            _moves = 0;
            _cleared = 0;
            Moves.Text = string.Format("MOVES 0");

            for (int row = 0; row < rows; row++)
            {
                ContentPanel.RowDefinitions.Add(new RowDefinition());
            }

            for (int col = 0; col < cols; col++)
            {
                ContentPanel.ColumnDefinitions.Add(new ColumnDefinition());
            }

            int rowCount = 0;
            int colCount = 0;
            for (int i = 0; i < rows * cols; i++)
            {
                var button = new Button();
                button.FontSize = 50;
                button.Click += Button_Click;
                Grid.SetColumn(button, colCount);
                colCount++;
                if (colCount == cols)
                {
                    colCount = 0;
                }

                Grid.SetRow(button, rowCount);
                rowCount++;
                if (rowCount == rows)
                {
                    rowCount = 0;
                }

                ContentPanel.Children.Add(button);
            }
        }

        private void Settings_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Settings.xaml", UriKind.Relative));
        }

        private void NewGame_Click(object sender, EventArgs e)
        {
            if (_isGameInProgress && MessageBox.Show("Are you sure want to start a new game?", "Confirm", MessageBoxButton.OKCancel) == MessageBoxResult.Cancel)
            {
                return;
            }

            StopTimer();
            CreateNewGame();
        }

        private void About_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/About.xaml", UriKind.Relative));
        }
    }

    public static class Extns
    {
        public static T GetControl<T>(this Grid grid, int row, int column) where T : FrameworkElement
        {
            int count = VisualTreeHelper.GetChildrenCount(grid);
            for (int i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(grid, i) as T;
                int r = Grid.GetRow(child);
                int c = Grid.GetColumn(child);
                if (r == row && c == column)
                {
                    return child;
                }
            }

            return null;
        }
    }
}