﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Text;

namespace OnlineTransliterator
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void TransliterateButton_Click(object sender, EventArgs e)
        {
            var listPickerItem = (ListPickerItem)LangCombo.SelectedItem;
            var resource = Application.Current.Resources[listPickerItem.Content.ToString()];
            WebClient webClient = new WebClient();
            webClient.Headers[HttpRequestHeader.Accept] = "application/json";
            webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
            webClient.UploadStringCompleted += (snder, args) =>
            {
                if (args.Error == null)
                {
                    var serializer = new DataContractJsonSerializer(typeof(RootObject));
                    using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(args.Result)))
                    {
                        var rootObject = serializer.ReadObject(stream) as RootObject;
                        TargetLang.FontFamily = resource as FontFamily;
                        TargetLang.Text = rootObject.result;
                    }
                }
            };
            webClient.UploadStringAsync(new Uri("http://silpa.org.in/JSONRPC"), "{\"method\":\"transliteration.transliterate\",\"params\":[\"" +
                SourceLang.Text + "\",\"" + listPickerItem.Tag.ToString() + "\"],\"id\":\"\"}");
        }
    }

    public class RootObject
    {
        public object error { get; set; }
        public string result { get; set; }
        public string id { get; set; }
    }
}