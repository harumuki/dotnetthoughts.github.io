﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication3
{
    public sealed class Contact
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public Phone Phone { get; set; }
    }

    public sealed class Phone
    {
        public string StdCode { get; set; }
        public string Number { get; set; }
    }
}
