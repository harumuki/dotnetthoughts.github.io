﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication3
{
    public class MainWindowViewModel : ViewModelBase
    {
        private ObservableCollection<dynamic> _comparisonResults;
        public MainWindowViewModel()
        {
            var compareFacade = new CompareFacade();
            List<dynamic> result1 = new List<dynamic>();

            compareFacade.ComparisonCompleted += (result) =>
            {
                result1 = result;
            };

            compareFacade.Compare(@"C:\Office_Projects", new Dictionary<string, string>() { 
            { "OpenProjects", @"C:\Open Projects" },
            });

            ComparisonResults = new ObservableCollection<dynamic>();
            result1.ForEach(x => ComparisonResults.Add(x));
            //result2.ForEach(x => ComparisonResults.Add(x));
        }

        public ObservableCollection<dynamic> ComparisonResults
        {
            get
            {
                return _comparisonResults;
            }
            set
            {
                _comparisonResults = value;
                RaisePropertyChanged("ComparisonResults");
            }
        }
    }

    public class CompareFacade
    {
        private List<Header> _headers;
        public event Action<List<dynamic>> ComparisonCompleted;
        public CompareFacade()
        {
            PopulateHeaders();
        }

        private void PopulateHeaders()
        {
            _headers = new List<Header>();

            _headers.Add(new Header() { DisplayName = "Zip Files", SearchCriteria = "*.zip" });
            _headers.Add(new Header() { DisplayName = "C# Files", SearchCriteria = "*.cs" });
            _headers.Add(new Header() { DisplayName = "RAR Files", SearchCriteria = "*.rar" });
        }

        public void Compare(string control, Dictionary<string, string> selectedDirs)
        {
            var result = new List<dynamic>();

            foreach (var header in _headers)
            {
                dynamic resultItem = new ExpandoObject();
                var x = resultItem as IDictionary<string, object>;
                x["Name"] = header.DisplayName;
                var files = Process(control, header);
                x["Control"] = files.Length;
                foreach (var selectedDir in selectedDirs)
                {
                    var files2 = Process(selectedDir.Value, header);
                    x[selectedDir.Key] = files2.Length;
                    x[selectedDir.Key + "_Files"] = files2;
                    x[selectedDir.Key + "_Difference"] = FileDiff(files.Length, files2.Length);
                }

                result.Add(resultItem);
            }

            if (ComparisonCompleted != null)
            {
                ComparisonCompleted(result);
            }
        }

        private static string[] Process(string directory, Header header)
        {
            return Directory.GetFiles(directory, header.SearchCriteria);
        }

        private int FileDiff(int count1, int count2)
        {
            if (count1 > count2)
            {
                return 1;
            }
            else if (count1 < count2)
            {
                return -1;
            }
            else if (count1 == count2)
            {
                return 0;
            }
            else
            {
                return 9;
            }
        }
    }

    internal class Header
    {
        public string DisplayName { get; set; }
        public string SearchCriteria { get; set; }
    }

    public class ViewModelBase : INotifyPropertyChanged
    {
        protected virtual void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
